# Connexted

Connexted is a coaching and community platform built with React, Supabase, and a Hono edge-function server. It features structured Programs and Courses with a Journey layer, a flexible container system for collaborative activities, a growth engine with pathways and badges, and comprehensive admin tools.

## Tech Stack

- **Frontend:** React 18, Vite, Tailwind CSS 4, Radix UI, Lucide React, React Router
- **Backend:** Supabase Edge Functions (Hono web server, Deno runtime)
- **Database:** PostgreSQL (Supabase) with Row Level Security
- **Auth:** Supabase Auth
- **AI:** Google AI (Gemini) for discussion summaries and content enrichment

## Key Features

- **Programs & Courses** -- Structured learning paths with Journeys, enrollments, tickets, and a course player
- **Growth Engine** -- Pathways, badges, and recommendations driving a retention loop
- **Container System** -- 11 container types for collaborative activities
- **Content Types** -- Documents, Books, Decks, Blogs, Pitches, Checklists, Episodes
- **Circles** -- Community groups with feed, forums, events, and documents
- **Markets** -- Company profiles, offerings, and marketplace
- **Membership Tiers** -- Configurable permission system based on user class
- **Admin Tools** -- Platform admin, program admin, circle admin dashboards

### Container Types

| Container | Purpose |
|---|---|
| Tables | Small group collaboration |
| Elevators | Quick introductions / pitches |
| Meetings | Scheduled gatherings |
| Builds | Project tracking |
| Standups | Daily check-ins |
| Meetups | Community events |
| Sprints | Time-boxed work periods |
| Libraries | Document collections |
| Magazines | Featured articles / news |
| Playlists | Video / audio collections |
| Events | Calendar items |

### Content Types

| Content | Purpose |
|---|---|
| Documents | PDFs, guides, external links |
| Books | Multi-chapter content |
| Decks | Presentations |
| Blogs | Articles |
| Pitches | Showcase presentations |
| Checklists | Task lists with items |
| Episodes | Podcast / video episodes |

## Setup

1. **Install Dependencies:**
   ```bash
   pnpm install
   ```

2. **Environment Variables:**
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server only)
   - `GOOGLE_AI_API_KEY` (for AI features)

3. **Run Development Server:**
   ```bash
   pnpm dev
   ```

## Architecture

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full architecture overview, including:
- Frontend routing and dashboard layout
- Sidebar decomposition (8 section components)
- Server decomposition (9 route modules + helpers)
- Database design patterns
- Security model

### Architecture Note: Single-Tenant MVP

Connexted currently runs a **single-tenant architecture** for MVP:
- Database has full multi-tenant foundation (`community_id` on all tables)
- Currently running ONE community
- **Do NOT** remove `community_id` scoping -- it provides clean data isolation for future expansion

## Documentation

- [Architecture Overview](docs/ARCHITECTURE.md) -- System design and technical decisions
- [Documentation Index](docs/DOCUMENTATION_INDEX.md) -- Complete index of all documentation
- [Database Structure](docs/DATABASE_STRUCTURE.md) -- Complete schema reference
- [Admin Guide](docs/ADMIN_GUIDE.md) -- Platform administration
- [Features](docs/FEATURES.md) -- Feature reference
- [Changelog](CHANGELOG.md) -- Version history
